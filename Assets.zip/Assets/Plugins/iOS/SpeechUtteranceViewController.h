
#import <UIKit/UIKit.h>

@interface SpeechUtteranceViewController : UIViewController
@end
